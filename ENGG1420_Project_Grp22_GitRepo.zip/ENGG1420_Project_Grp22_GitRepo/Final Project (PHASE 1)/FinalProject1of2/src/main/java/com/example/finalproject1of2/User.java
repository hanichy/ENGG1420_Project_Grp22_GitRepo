package com.example.finalproject1of2;

public abstract class User {
    // User class
}
